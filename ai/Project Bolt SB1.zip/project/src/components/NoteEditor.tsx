import React, { useState, useEffect } from 'react';
import { Note } from '../types';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Eye, Edit, Pin, PinOff } from 'lucide-react';

interface NoteEditorProps {
  note: Note;
  onUpdateNote: (note: Note) => void;
}

const NoteEditor: React.FC<NoteEditorProps> = ({ note, onUpdateNote }) => {
  const [title, setTitle] = useState(note.title);
  const [content, setContent] = useState(note.content);
  const [isPreview, setIsPreview] = useState(false);

  useEffect(() => {
    setTitle(note.title);
    setContent(note.content);
  }, [note.id, note.title, note.content]);

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTitle(e.target.value);
    onUpdateNote({ ...note, title: e.target.value });
  };

  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setContent(e.target.value);
    onUpdateNote({ ...note, content: e.target.value });
  };

  const togglePin = () => {
    onUpdateNote({ ...note, isPinned: !note.isPinned });
  };

  return (
    <div className="h-full flex flex-col">
      <div className="border-b border-gray-200 dark:border-gray-700 p-4 flex items-center justify-between">
        <input
          type="text"
          value={title}
          onChange={handleTitleChange}
          placeholder="Note title"
          className="text-xl font-bold w-full bg-transparent focus:outline-none text-gray-900 dark:text-white"
        />
        <div className="flex items-center space-x-2">
          <button
            onClick={togglePin}
            className="p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-500 dark:text-gray-400"
            title={note.isPinned ? "Unpin note" : "Pin note"}
          >
            {note.isPinned ? <PinOff size={18} /> : <Pin size={18} />}
          </button>
          <button
            onClick={() => setIsPreview(!isPreview)}
            className="p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-500 dark:text-gray-400"
            title={isPreview ? "Edit mode" : "Preview mode"}
          >
            {isPreview ? <Edit size={18} /> : <Eye size={18} />}
          </button>
        </div>
      </div>
      
      <div className="flex-1 overflow-auto">
        {isPreview ? (
          <div className="p-4 prose prose-sm max-w-none dark:prose-invert">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>
              {content}
            </ReactMarkdown>
          </div>
        ) : (
          <textarea
            value={content}
            onChange={handleContentChange}
            placeholder="Start typing your note here... (Markdown supported)"
            className="p-4 w-full h-full bg-transparent resize-none focus:outline-none text-gray-700 dark:text-gray-300 font-mono"
          />
        )}
      </div>
      
      <div className="p-2 text-xs text-gray-500 dark:text-gray-400 border-t border-gray-200 dark:border-gray-700">
        <p>Markdown supported. Use # for headings, * for lists, **bold**, *italic*, etc.</p>
      </div>
    </div>
  );
};

export default NoteEditor;