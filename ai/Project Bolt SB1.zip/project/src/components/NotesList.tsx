import React from 'react';
import { Trash2, Pin } from 'lucide-react';
import { Note } from '../types';
import { formatDate, truncateText } from '../utils/helpers';

interface NotesListProps {
  notes: Note[];
  categories: { id: string, name: string, color: string }[];
  activeNoteId: string | null;
  onSelectNote: (id: string) => void;
  onDeleteNote: (id: string) => void;
}

const NotesList: React.FC<NotesListProps> = ({ 
  notes, 
  categories,
  activeNoteId, 
  onSelectNote, 
  onDeleteNote 
}) => {
  if (notes.length === 0) {
    return (
      <div className="p-4 text-center text-gray-500 dark:text-gray-400">
        No notes found
      </div>
    );
  }

  // Sort notes: pinned first, then by updated date
  const sortedNotes = [...notes].sort((a, b) => {
    if (a.isPinned && !b.isPinned) return -1;
    if (!a.isPinned && b.isPinned) return 1;
    return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
  });

  const getCategoryColor = (categoryId: string) => {
    const category = categories.find(c => c.id === categoryId);
    return category ? category.color : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
  };

  const getCategoryName = (categoryId: string) => {
    const category = categories.find(c => c.id === categoryId);
    return category ? category.name : '';
  };

  return (
    <div className="divide-y divide-gray-200 dark:divide-gray-700">
      {sortedNotes.map(note => (
        <div 
          key={note.id}
          className={`p-4 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 ${
            activeNoteId === note.id ? 'bg-blue-50 dark:bg-gray-700' : ''
          }`}
          onClick={() => onSelectNote(note.id)}
        >
          <div className="flex justify-between items-start">
            <div className="flex-1 min-w-0">
              <div className="flex items-center">
                <h3 className="text-sm font-medium text-gray-900 dark:text-white truncate">
                  {note.title}
                </h3>
                {note.isPinned && (
                  <Pin size={14} className="ml-1 text-blue-500" />
                )}
              </div>
              <div className="flex items-center mt-1 space-x-2">
                <span className={`text-xs px-2 py-0.5 rounded-full ${getCategoryColor(note.category)}`}>
                  {getCategoryName(note.category)}
                </span>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {formatDate(note.updatedAt)}
                </p>
              </div>
              <p className="mt-1 text-xs text-gray-500 dark:text-gray-400 line-clamp-2">
                {truncateText(note.content, 100)}
              </p>
            </div>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onDeleteNote(note.id);
              }}
              className="ml-2 p-1 text-gray-400 hover:text-red-500 dark:hover:text-red-400 rounded-full hover:bg-gray-200 dark:hover:bg-gray-600"
            >
              <Trash2 size={16} />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default NotesList;