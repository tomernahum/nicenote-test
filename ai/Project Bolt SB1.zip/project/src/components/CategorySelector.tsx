import React, { useState } from 'react';
import { Plus, Check } from 'lucide-react';
import { Category } from '../types';
import { generateCategoryColor } from '../utils/helpers';

interface CategorySelectorProps {
  categories: Category[];
  selectedCategory: string;
  onSelectCategory: (categoryId: string) => void;
  onAddCategory: (category: Category) => void;
}

const CategorySelector: React.FC<CategorySelectorProps> = ({
  categories,
  selectedCategory,
  onSelectCategory,
  onAddCategory
}) => {
  const [isAdding, setIsAdding] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');

  const handleAddCategory = () => {
    if (newCategoryName.trim()) {
      const newCategory: Category = {
        id: Date.now().toString(),
        name: newCategoryName.trim(),
        color: generateCategoryColor()
      };
      onAddCategory(newCategory);
      setNewCategoryName('');
      setIsAdding(false);
      onSelectCategory(newCategory.id);
    }
  };

  return (
    <div className="mb-4">
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300">Categories</h3>
        <button
          onClick={() => setIsAdding(!isAdding)}
          className="p-1 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
        >
          <Plus size={16} />
        </button>
      </div>
      
      {isAdding && (
        <div className="mb-2 flex">
          <input
            type="text"
            value={newCategoryName}
            onChange={(e) => setNewCategoryName(e.target.value)}
            placeholder="New category"
            className="flex-1 px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded-l-md focus:outline-none focus:ring-1 focus:ring-blue-500 dark:bg-gray-800 dark:text-white"
            onKeyDown={(e) => e.key === 'Enter' && handleAddCategory()}
          />
          <button
            onClick={handleAddCategory}
            className="px-2 py-1 bg-blue-500 text-white rounded-r-md hover:bg-blue-600"
          >
            <Check size={16} />
          </button>
        </div>
      )}
      
      <div className="flex flex-wrap gap-2">
        {categories.map(category => (
          <button
            key={category.id}
            onClick={() => onSelectCategory(category.id)}
            className={`px-2 py-1 text-xs rounded-md ${category.color} ${
              selectedCategory === category.id ? 'ring-2 ring-offset-2 ring-blue-500 dark:ring-offset-gray-800' : ''
            }`}
          >
            {category.name}
          </button>
        ))}
      </div>
    </div>
  );
};

export default CategorySelector;