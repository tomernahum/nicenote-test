import React, { useState, useEffect } from 'react';
import { Moon, Sun, Plus, Trash2, Search, Menu, X, Settings, Info } from 'lucide-react';
import NotesList from './components/NotesList';
import NoteEditor from './components/NoteEditor';
import CategorySelector from './components/CategorySelector';
import { Note, Category } from './types';
import { getDefaultCategories } from './utils/helpers';

function App() {
  const [darkMode, setDarkMode] = useState(() => {
    const savedMode = localStorage.getItem('darkMode');
    return savedMode ? JSON.parse(savedMode) : window.matchMedia('(prefers-color-scheme: dark)').matches;
  });
  
  const [notes, setNotes] = useState<Note[]>(() => {
    const savedNotes = localStorage.getItem('notes');
    return savedNotes ? JSON.parse(savedNotes) : [];
  });
  
  const [categories, setCategories] = useState<Category[]>(() => {
    const savedCategories = localStorage.getItem('categories');
    return savedCategories ? JSON.parse(savedCategories) : getDefaultCategories();
  });
  
  const [activeNoteId, setActiveNoteId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [showWelcome, setShowWelcome] = useState(() => {
    return notes.length === 0;
  });
  
  useEffect(() => {
    localStorage.setItem('darkMode', JSON.stringify(darkMode));
    document.documentElement.classList.toggle('dark', darkMode);
  }, [darkMode]);
  
  useEffect(() => {
    localStorage.setItem('notes', JSON.stringify(notes));
  }, [notes]);
  
  useEffect(() => {
    localStorage.setItem('categories', JSON.stringify(categories));
  }, [categories]);
  
  useEffect(() => {
    if (notes.length > 0 && !activeNoteId) {
      setActiveNoteId(notes[0].id);
    }
  }, [notes, activeNoteId]);
  
  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };
  
  const createNewNote = () => {
    const newNote: Note = {
      id: Date.now().toString(),
      title: 'Untitled Note',
      content: '',
      category: selectedCategory === 'all' ? categories[0]?.id || 'personal' : selectedCategory,
      isPinned: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    setNotes([newNote, ...notes]);
    setActiveNoteId(newNote.id);
    setShowWelcome(false);
  };
  
  const updateNote = (updatedNote: Note) => {
    setNotes(notes.map(note => 
      note.id === updatedNote.id 
        ? { ...updatedNote, updatedAt: new Date().toISOString() } 
        : note
    ));
  };
  
  const deleteNote = (id: string) => {
    setNotes(notes.filter(note => note.id !== id));
    if (activeNoteId === id) {
      setActiveNoteId(notes.length > 1 ? notes[0].id === id ? notes[1].id : notes[0].id : null);
    }
  };
  
  const addCategory = (category: Category) => {
    setCategories([...categories, category]);
  };
  
  const filteredNotes = notes.filter(note => {
    const matchesSearch = 
      note.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
      note.content.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === 'all' || note.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });
  
  const activeNote = notes.find(note => note.id === activeNoteId) || null;
  
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const createWelcomeNote = () => {
    const welcomeNote: Note = {
      id: Date.now().toString(),
      title: 'Welcome to Notes App',
      content: `# Welcome to Your Notes App! 👋

## Features:

* **Markdown Support** - Format your notes with headings, lists, and more
* **Dark Mode** - Toggle between light and dark themes
* **Categories** - Organize your notes by category
* **Pin Important Notes** - Keep critical information at the top
* **Search** - Find notes quickly with the search bar

## Markdown Tips:

* Use \`#\` for headings (# Heading 1, ## Heading 2)
* Use \`*\` or \`-\` for bullet lists
* Use \`1.\` for numbered lists
* Use \`**bold**\` for **bold text**
* Use \`*italic*\` for *italic text*
* Use \`[link text](url)\` for [links](https://example.com)
* Use \`\`\`code\`\`\` for code blocks

Happy note-taking! 📝`,
      category: 'personal',
      isPinned: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    setNotes([welcomeNote]);
    setActiveNoteId(welcomeNote.id);
    setShowWelcome(false);
  };

  return (
    <div className={`min-h-screen flex flex-col ${darkMode ? 'dark' : ''}`}>
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center">
            <button 
              onClick={toggleSidebar}
              className="mr-4 p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700 md:hidden"
            >
              {sidebarOpen ? <X size={20} className="text-gray-700 dark:text-gray-300" /> : <Menu size={20} className="text-gray-700 dark:text-gray-300" />}
            </button>
            <h1 className="text-xl font-bold text-gray-800 dark:text-white">Notes</h1>
          </div>
          <div className="flex items-center space-x-2">
            <button 
              onClick={toggleDarkMode}
              className="p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700"
              title={darkMode ? "Switch to light mode" : "Switch to dark mode"}
            >
              {darkMode ? 
                <Sun size={20} className="text-gray-700 dark:text-gray-300" /> : 
                <Moon size={20} className="text-gray-700 dark:text-gray-300" />
              }
            </button>
            <button 
              className="p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700"
              title="Settings"
            >
              <Settings size={20} className="text-gray-700 dark:text-gray-300" />
            </button>
          </div>
        </div>
      </header>
      
      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <aside 
          className={`w-80 bg-gray-50 dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700 flex flex-col ${
            sidebarOpen ? 'block' : 'hidden'
          } md:block transition-all duration-300 ease-in-out`}
        >
          <div className="p-4 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-700 dark:text-gray-300">My Notes</h2>
              <button 
                onClick={createNewNote}
                className="p-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700"
                title="Create new note"
              >
                <Plus size={20} className="text-gray-700 dark:text-gray-300" />
              </button>
            </div>
            <div className="relative mb-4">
              <input
                type="text"
                placeholder="Search notes..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full px-4 py-2 pl-10 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
              />
              <Search size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            </div>
            
            <CategorySelector 
              categories={categories}
              selectedCategory={selectedCategory}
              onSelectCategory={setSelectedCategory}
              onAddCategory={addCategory}
            />
          </div>
          <div className="flex-1 overflow-y-auto">
            <NotesList 
              notes={filteredNotes} 
              categories={categories}
              activeNoteId={activeNoteId} 
              onSelectNote={setActiveNoteId}
              onDeleteNote={deleteNote}
            />
          </div>
        </aside>
        
        {/* Note Editor */}
        <main className="flex-1 overflow-hidden bg-white dark:bg-gray-800">
          {activeNote ? (
            <NoteEditor 
              note={activeNote} 
              onUpdateNote={updateNote} 
            />
          ) : (
            <div className="h-full flex items-center justify-center p-4">
              <div className="text-center max-w-md">
                {showWelcome ? (
                  <>
                    <div className="mb-6 flex justify-center">
                      <Info size={48} className="text-blue-500" />
                    </div>
                    <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">Welcome to Notes App</h2>
                    <p className="text-gray-600 dark:text-gray-300 mb-6">
                      This is a simple, yet powerful notes application with markdown support, categories, and dark mode.
                    </p>
                    <div className="flex flex-col space-y-3 sm:flex-row sm:space-y-0 sm:space-x-3 justify-center">
                      <button
                        onClick={createWelcomeNote}
                        className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition-colors"
                      >
                        Create a welcome note
                      </button>
                      <button
                        onClick={createNewNote}
                        className="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
                      >
                        Start with a blank note
                      </button>
                    </div>
                  </>
                ) : (
                  <>
                    <p className="text-gray-500 dark:text-gray-400 mb-4">No note selected</p>
                    <button
                      onClick={createNewNote}
                      className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition-colors"
                    >
                      Create a new note
                    </button>
                  </>
                )}
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

export default App;