import { format, formatDistanceToNow } from 'date-fns';
import { Category } from '../types';

export const formatDate = (dateString: string): string => {
  const date = new Date(dateString);
  const now = new Date();
  
  // If the date is today, show relative time
  if (date.toDateString() === now.toDateString()) {
    return formatDistanceToNow(date, { addSuffix: true });
  }
  
  // If the date is within the last week, show day of week
  if (now.getTime() - date.getTime() < 7 * 24 * 60 * 60 * 1000) {
    return format(date, 'EEEE, h:mm a');
  }
  
  // Otherwise show the full date
  return format(date, 'MMM d, yyyy');
};

export const generateCategoryColor = (): string => {
  const colors = [
    'bg-red-100 text-red-800',
    'bg-blue-100 text-blue-800',
    'bg-green-100 text-green-800',
    'bg-yellow-100 text-yellow-800',
    'bg-purple-100 text-purple-800',
    'bg-pink-100 text-pink-800',
    'bg-indigo-100 text-indigo-800',
    'bg-teal-100 text-teal-800'
  ];
  
  return colors[Math.floor(Math.random() * colors.length)];
};

export const getDefaultCategories = (): Category[] => {
  return [
    { id: 'personal', name: 'Personal', color: 'bg-blue-100 text-blue-800' },
    { id: 'work', name: 'Work', color: 'bg-green-100 text-green-800' },
    { id: 'ideas', name: 'Ideas', color: 'bg-purple-100 text-purple-800' },
    { id: 'tasks', name: 'Tasks', color: 'bg-yellow-100 text-yellow-800' }
  ];
};

export const truncateText = (text: string, maxLength: number): string => {
  // Remove markdown syntax for preview
  const plainText = text
    .replace(/#{1,6}\s+/g, '') // Remove headings
    .replace(/\*\*(.+?)\*\*/g, '$1') // Remove bold
    .replace(/\*(.+?)\*/g, '$1') // Remove italic
    .replace(/\[(.+?)\]\(.+?\)/g, '$1') // Remove links
    .replace(/```[\s\S]*?```/g, '') // Remove code blocks
    .replace(/`(.+?)`/g, '$1') // Remove inline code
    .replace(/>\s(.+)/g, '$1') // Remove blockquotes
    .replace(/- (.+)/g, '$1') // Remove list items
    .replace(/\d+\. (.+)/g, '$1'); // Remove numbered list items
  
  if (plainText.length <= maxLength) return plainText;
  return plainText.substring(0, maxLength) + '...';
};