/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        gray: {
          50: '#f9fafb',
          100: '#f3f4f6',
          200: '#e5e7eb',
          300: '#d1d5db',
          400: '#9ca3af',
          500: '#6b7280',
          600: '#4b5563',
          700: '#374151',
          800: '#1f2937',
          900: '#111827',
        },
      },
      typography: (theme) => ({
        DEFAULT: {
          css: {
            color: theme('colors.gray.900'),
            a: {
              color: theme('colors.blue.600'),
              '&:hover': {
                color: theme('colors.blue.700'),
              },
            },
            'h1, h2, h3, h4, h5, h6': {
              color: theme('colors.gray.900'),
              marginTop: '1.5em',
              marginBottom: '0.5em',
            },
            code: {
              color: theme('colors.pink.600'),
              backgroundColor: theme('colors.gray.100'),
              padding: '0.2em 0.4em',
              borderRadius: '0.25rem',
              fontWeight: '400',
            },
            'code::before': {
              content: '""',
            },
            'code::after': {
              content: '""',
            },
          },
        },
        invert: {
          css: {
            color: theme('colors.gray.200'),
            a: {
              color: theme('colors.blue.400'),
              '&:hover': {
                color: theme('colors.blue.300'),
              },
            },
            'h1, h2, h3, h4, h5, h6': {
              color: theme('colors.gray.100'),
            },
            code: {
              color: theme('colors.pink.400'),
              backgroundColor: theme('colors.gray.800'),
            },
          },
        },
      }),
    },
  },
  plugins: [
    function ({ addComponents }) {
      addComponents({
        '.prose': {
          '& h1': { fontSize: '1.875rem', fontWeight: '700', lineHeight: '2.25rem' },
          '& h2': { fontSize: '1.5rem', fontWeight: '700', lineHeight: '2rem' },
          '& h3': { fontSize: '1.25rem', fontWeight: '600', lineHeight: '1.75rem' },
          '& h4': { fontSize: '1.125rem', fontWeight: '600', lineHeight: '1.75rem' },
          '& h5': { fontSize: '1rem', fontWeight: '600', lineHeight: '1.5rem' },
          '& h6': { fontSize: '0.875rem', fontWeight: '600', lineHeight: '1.25rem' },
          '& p': { marginTop: '1rem', marginBottom: '1rem' },
          '& ul': { listStyleType: 'disc', paddingLeft: '1.5rem', marginTop: '1rem', marginBottom: '1rem' },
          '& ol': { listStyleType: 'decimal', paddingLeft: '1.5rem', marginTop: '1rem', marginBottom: '1rem' },
          '& li': { marginTop: '0.5rem', marginBottom: '0.5rem' },
          '& blockquote': { 
            borderLeftWidth: '4px', 
            borderLeftColor: '#e5e7eb', 
            paddingLeft: '1rem',
            fontStyle: 'italic',
            marginTop: '1rem',
            marginBottom: '1rem',
          },
          '& a': { color: '#3b82f6', textDecoration: 'underline' },
          '& code': { 
            backgroundColor: '#f3f4f6', 
            borderRadius: '0.25rem', 
            padding: '0.125rem 0.25rem',
            fontFamily: 'monospace',
          },
          '& pre': { 
            backgroundColor: '#1f2937', 
            color: '#f9fafb',
            padding: '1rem',
            borderRadius: '0.375rem',
            overflowX: 'auto',
            marginTop: '1rem',
            marginBottom: '1rem',
          },
          '& pre code': {
            backgroundColor: 'transparent',
            padding: '0',
            color: 'inherit',
          },
          '& hr': {
            borderTopWidth: '1px',
            marginTop: '1.5rem',
            marginBottom: '1.5rem',
          },
          '& table': {
            width: '100%',
            tableLayout: 'auto',
            textAlign: 'left',
            marginTop: '1rem',
            marginBottom: '1rem',
          },
          '& thead': {
            borderBottomWidth: '1px',
            borderBottomColor: '#e5e7eb',
          },
          '& th': {
            padding: '0.5rem',
            fontWeight: '600',
          },
          '& td': {
            padding: '0.5rem',
            borderBottomWidth: '1px',
            borderBottomColor: '#e5e7eb',
          },
        },
        '.prose-invert': {
          '& blockquote': { borderLeftColor: '#4b5563' },
          '& code': { backgroundColor: '#374151' },
          '& a': { color: '#60a5fa' },
          '& thead': { borderBottomColor: '#4b5563' },
          '& td': { borderBottomColor: '#4b5563' },
        },
        '.line-clamp-2': {
          display: '-webkit-box',
          '-webkit-line-clamp': '2',
          '-webkit-box-orient': 'vertical',
          overflow: 'hidden',
        },
      });
    },
  ],
};