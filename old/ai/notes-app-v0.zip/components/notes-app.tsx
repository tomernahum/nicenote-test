"use client"

import { useState, useEffect } from "react"
import { Sidebar } from "@/components/sidebar"
import { NoteEditor } from "@/components/note-editor"
import { ThemeToggle } from "@/components/theme-toggle"
import { PlusCircle, Menu } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useMediaQuery } from "@/hooks/use-media-query"

export type Note = {
  id: string
  title: string
  content: string
  category: string
  updatedAt: Date
  isPinned: boolean
}

export type Category = {
  id: string
  name: string
}

export default function NotesApp() {
  const [darkMode, setDarkMode] = useState(false)
  const [isSidebarOpen, setIsSidebarOpen] = useState(true)
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [selectedNote, setSelectedNote] = useState<string | null>(null)
  const isMobile = useMediaQuery("(max-width: 768px)")

  const [notes, setNotes] = useState<Note[]>(() => {
    // Default notes
    return [
      {
        id: "1",
        title: "Welcome to Notes",
        content: "This is your first note. Start writing!",
        category: "Personal",
        updatedAt: new Date(),
        isPinned: false,
      },
      {
        id: "2",
        title: "Shopping List",
        content: "- Milk\n- Eggs\n- Bread\n- Apples",
        category: "Personal",
        updatedAt: new Date(Date.now() - 86400000),
        isPinned: false,
      },
      {
        id: "3",
        title: "Project Ideas",
        content: "1. Build a notes app\n2. Create a portfolio website\n3. Learn a new framework",
        category: "Work",
        updatedAt: new Date(Date.now() - 172800000),
        isPinned: false,
      },
    ]
  })

  const [categories, setCategories] = useState<Category[]>([
    { id: "1", name: "All Notes" },
    { id: "2", name: "Personal" },
    { id: "3", name: "Work" },
  ])

  // Initialize selected category and note
  useEffect(() => {
    if (categories.length > 0 && !selectedCategory) {
      setSelectedCategory(categories[0].id)
    }

    if (notes.length > 0 && !selectedNote) {
      setSelectedNote(notes[0].id)
    }
  }, [categories, notes, selectedCategory, selectedNote])

  // Toggle dark mode
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [darkMode])

  // Close sidebar when resizing to mobile
  useEffect(() => {
    if (isMobile) {
      setIsSidebarOpen(false)
    } else {
      setIsSidebarOpen(true)
    }
  }, [isMobile])

  // Filter notes by selected category
  const filteredNotes =
    selectedCategory && selectedCategory !== "1"
      ? notes.filter((note) => {
          const category = categories.find((c) => c.id === selectedCategory)
          return category && note.category === category.name
        })
      : notes

  // Sort notes: pinned first, then by updatedAt
  const sortedNotes = [...filteredNotes].sort((a, b) => {
    if (a.isPinned && !b.isPinned) return -1
    if (!a.isPinned && b.isPinned) return 1
    return b.updatedAt.getTime() - a.updatedAt.getTime()
  })

  // Get the selected note
  const currentNote = notes.find((note) => note.id === selectedNote)

  // Create a new note
  const createNote = () => {
    const newNote: Note = {
      id: Date.now().toString(),
      title: "New Note",
      content: "",
      category:
        selectedCategory === "1" ? "Personal" : categories.find((c) => c.id === selectedCategory)?.name || "Personal",
      updatedAt: new Date(),
      isPinned: false,
    }

    setNotes([newNote, ...notes])
    setSelectedNote(newNote.id)

    // On mobile, close the sidebar when creating a new note
    if (isMobile) {
      setIsSidebarOpen(false)
    }
  }

  // Update a note
  const updateNote = (id: string, data: Partial<Note>) => {
    setNotes(notes.map((note) => (note.id === id ? { ...note, ...data, updatedAt: new Date() } : note)))
  }

  // Delete a note
  const deleteNote = (id: string) => {
    setNotes(notes.filter((note) => note.id !== id))
    if (selectedNote === id) {
      setSelectedNote(notes.length > 1 ? notes.filter((note) => note.id !== id)[0]?.id : null)
    }
  }

  // Toggle pin status of a note
  const togglePinNote = (id: string) => {
    setNotes(notes.map((note) => (note.id === id ? { ...note, isPinned: !note.isPinned } : note)))
  }

  // Handle back button on mobile
  const handleBack = () => {
    setSelectedNote(null)
    setIsSidebarOpen(true)
  }

  return (
    <div className="h-screen flex flex-col bg-background text-foreground">
      {/* Header */}
      <header className="border-b p-4 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setIsSidebarOpen(!isSidebarOpen)}>
            <Menu className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-semibold">Notes</h1>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={createNote}>
            <PlusCircle className="h-5 w-5" />
          </Button>
          <ThemeToggle darkMode={darkMode} setDarkMode={setDarkMode} />
        </div>
      </header>

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden relative">
        {/* Sidebar - overlay on mobile when open */}
        {(isSidebarOpen || !isMobile) && (
          <div className={`${isMobile ? "absolute inset-0 z-20 bg-background" : "relative"} w-80 border-r`}>
            <Sidebar
              categories={categories}
              selectedCategory={selectedCategory}
              onSelectCategory={setSelectedCategory}
              notes={sortedNotes}
              selectedNote={selectedNote}
              onSelectNote={(id) => {
                setSelectedNote(id)
                if (isMobile) {
                  setIsSidebarOpen(false)
                }
              }}
              onCreateNote={createNote}
              onDeleteNote={deleteNote}
              onTogglePinNote={togglePinNote}
            />
          </div>
        )}

        {/* Note Editor */}
        {(!isMobile || (isMobile && !isSidebarOpen)) && (
          <div className="flex-1 overflow-auto">
            {currentNote ? (
              <NoteEditor note={currentNote} onUpdateNote={updateNote} onBack={handleBack} />
            ) : (
              <div className="flex items-center justify-center h-full text-muted-foreground">
                Select a note or create a new one
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

