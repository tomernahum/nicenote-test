"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { ChevronLeft } from "lucide-react"
import type { Note } from "@/components/notes-app"

interface NoteEditorProps {
  note: Note
  onUpdateNote: (id: string, data: Partial<Note>) => void
  onBack: () => void
}

export function NoteEditor({ note, onUpdateNote, onBack }: NoteEditorProps) {
  const [title, setTitle] = useState(note.title)
  const [content, setContent] = useState(note.content)

  // Update local state when selected note changes
  useEffect(() => {
    setTitle(note.title)
    setContent(note.content)
  }, [note])

  // Update note in parent component
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (title !== note.title || content !== note.content) {
        onUpdateNote(note.id, { title, content })
      }
    }, 500)

    return () => clearTimeout(timeoutId)
  }, [title, content, note.id, note.title, note.content, onUpdateNote])

  return (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b flex items-center gap-2">
        <Button variant="ghost" size="icon" className="md:hidden mr-2" onClick={onBack}>
          <ChevronLeft className="h-5 w-5" />
        </Button>
        <Input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="text-lg font-medium border-none focus-visible:ring-0 focus-visible:ring-offset-0 px-0"
          placeholder="Note title"
        />
      </div>
      <div className="flex-1 overflow-auto p-4">
        <Textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          className="w-full h-full min-h-[calc(100vh-12rem)] resize-none border-none focus-visible:ring-0 focus-visible:ring-offset-0 p-0"
          placeholder="Start writing..."
        />
      </div>
    </div>
  )
}

