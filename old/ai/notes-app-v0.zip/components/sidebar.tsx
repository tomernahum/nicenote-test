"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Input } from "@/components/ui/input"
import { PlusCircle, Search, Trash2, Pin } from "lucide-react"
import type { Category, Note } from "@/components/notes-app"

interface SidebarProps {
  categories: Category[]
  selectedCategory: string | null
  onSelectCategory: (id: string) => void
  notes: Note[]
  selectedNote: string | null
  onSelectNote: (id: string) => void
  onCreateNote: () => void
  onDeleteNote: (id: string) => void
  onTogglePinNote: (id: string) => void
}

export function Sidebar({
  categories,
  selectedCategory,
  onSelectCategory,
  notes,
  selectedNote,
  onSelectNote,
  onCreateNote,
  onDeleteNote,
  onTogglePinNote,
}: SidebarProps) {
  const [searchQuery, setSearchQuery] = useState("")

  const filteredNotes = searchQuery
    ? notes.filter(
        (note) =>
          note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          note.content.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    : notes

  // Format date to relative time (today, yesterday, or date)
  const formatDate = (date: Date) => {
    const now = new Date()
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())
    const noteDate = new Date(date.getFullYear(), date.getMonth(), date.getDate())

    const diffTime = today.getTime() - noteDate.getTime()
    const diffDays = diffTime / (1000 * 60 * 60 * 24)

    if (diffDays < 1) return "Today"
    if (diffDays < 2) return "Yesterday"
    return date.toLocaleDateString()
  }

  return (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b">
        <div className="flex items-center gap-2 mb-4">
          <Button variant="outline" size="sm" className="w-full" onClick={onCreateNote}>
            <PlusCircle className="h-4 w-4 mr-2" />
            New Note
          </Button>
        </div>
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search notes..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>
      <ScrollArea className="flex-1">
        <div className="p-4">
          <h2 className="font-semibold mb-2">Categories</h2>
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? "secondary" : "ghost"}
              className="w-full justify-start mb-1"
              onClick={() => onSelectCategory(category.id)}
            >
              {category.name}
            </Button>
          ))}
        </div>
        <div className="px-4 py-2">
          <h2 className="font-semibold mb-2">Notes</h2>
          <div className="space-y-1">
            {filteredNotes.map((note) => (
              <div
                key={note.id}
                className={`p-2 rounded-md cursor-pointer hover:bg-muted/50 ${
                  selectedNote === note.id ? "bg-muted" : ""
                }`}
                onClick={() => onSelectNote(note.id)}
                onContextMenu={(e) => {
                  e.preventDefault()
                  onTogglePinNote(note.id)
                }}
              >
                <div className="flex justify-between items-start">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium truncate flex items-center">
                      {note.isPinned && <Pin className="h-3 w-3 mr-1 text-muted-foreground" />}
                      {note.title}
                    </h3>
                    <p className="text-sm text-muted-foreground truncate">{note.content.split("\n")[0]}</p>
                    <p className="text-xs text-muted-foreground">{formatDate(note.updatedAt)}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 opacity-0 group-hover:opacity-100 hover:opacity-100"
                    onClick={(e) => {
                      e.stopPropagation()
                      onDeleteNote(note.id)
                    }}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </ScrollArea>
    </div>
  )
}

